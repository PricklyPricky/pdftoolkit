import { PDFDocument, rgb, degrees, StandardFonts } from 'pdf-lib';
import { pdfjsLib } from './pdfWorker';
import JSZip from 'jszip';
import { Document, Packer, Paragraph, TextRun, HeadingLevel, PageBreak, AlignmentType } from 'docx';
import mammoth from 'mammoth';
import { jsPDF } from 'jspdf';
import html2canvas from 'html2canvas';
import { UploadedFile, PageItem, WatermarkOptions, PageNumberOptions } from '../types';

/**
 * Loads metadata and page thumbnails for an uploaded file
 */
export async function processUploadedFile(file: File): Promise<UploadedFile> {
  const id = Math.random().toString(36).substring(2, 11);
  const sizeFormatted = (file.size / (1024 * 1024)).toFixed(2) + ' MB';
  const rawSize = file.size;

  const result: UploadedFile = {
    id,
    file,
    name: file.name,
    sizeFormatted,
    rawSize,
    pageCount: 0,
    thumbnails: [],
    pages: [],
  };

  const isPdf = file.type === 'application/pdf' || file.name.toLowerCase().endsWith('.pdf');
  const isImage = file.type.startsWith('image/');
  const isWord =
    file.name.toLowerCase().endsWith('.docx') ||
    file.name.toLowerCase().endsWith('.doc') ||
    file.type.includes('wordprocessingml') ||
    file.type.includes('msword');

  if (isPdf) {
    try {
      const arrayBuffer = await file.arrayBuffer();
      const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
      result.pageCount = pdf.numPages;

      // Extract thumbnails for first 6 pages initially for performance, or up to 20 for organize tool
      const maxPagesToPreview = Math.min(pdf.numPages, 12);
      const pages: PageItem[] = [];

      for (let i = 1; i <= maxPagesToPreview; i++) {
        const page = await pdf.getPage(i);
        const viewport = page.getViewport({ scale: 0.35 });
        const canvas = document.createElement('canvas');
        const context = canvas.getContext('2d');
        canvas.height = viewport.height;
        canvas.width = viewport.width;

        if (context) {
          await page.render({ canvasContext: context, viewport, canvas } as any).promise;
          const thumb = canvas.toDataURL('image/jpeg', 0.85);
          result.thumbnails.push(thumb);
          pages.push({
            pageNumber: i,
            rotation: 0,
            thumbnail: thumb,
          });
        }
      }

      // If PDF has more pages, fill remaining page references
      for (let i = maxPagesToPreview + 1; i <= pdf.numPages; i++) {
        pages.push({
          pageNumber: i,
          rotation: 0,
          thumbnail: result.thumbnails[0] || '',
        });
      }

      result.pages = pages;
    } catch (err) {
      console.error('Error reading PDF metadata:', err);
    }
  } else if (isWord) {
    try {
      const arrayBuffer = await file.arrayBuffer();
      const mammothResult = await mammoth.convertToHtml({ arrayBuffer });
      result.wordHtml = mammothResult.value;
      const rawTextResult = await mammoth.extractRawText({ arrayBuffer });
      result.extractedText = rawTextResult.value;

      // Estimate page count (~500 words per page)
      const wordCount = result.extractedText.trim().split(/\s+/).filter(Boolean).length;
      result.pageCount = Math.max(1, Math.ceil(wordCount / 450));

      // Generate a document preview thumbnail canvas
      const canvas = document.createElement('canvas');
      canvas.width = 240;
      canvas.height = 320;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, 240, 320);
        ctx.fillStyle = '#2563eb';
        ctx.fillRect(20, 20, 200, 16);
        ctx.fillStyle = '#e2e8f0';
        for (let y = 50; y < 290; y += 14) {
          const width = 160 + ((y * 7) % 35);
          ctx.fillRect(20, y, Math.min(width, 195), 8);
        }
        result.thumbnails.push(canvas.toDataURL('image/png'));
      }
    } catch (err) {
      console.error('Error reading Word file:', err);
    }
  } else if (isImage) {
    try {
      const dataUrl = await new Promise<string>((resolve) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result as string);
        reader.readAsDataURL(file);
      });
      result.thumbnails.push(dataUrl);
      result.pageCount = 1;
    } catch (err) {
      console.error('Error loading image:', err);
    }
  }

  return result;
}

/**
 * Merge multiple PDFs into one
 */
export async function mergePdfs(files: UploadedFile[]): Promise<Uint8Array> {
  const mergedPdf = await PDFDocument.create();

  for (const f of files) {
    const arrayBuffer = await f.file.arrayBuffer();
    const donorPdf = await PDFDocument.load(arrayBuffer, { ignoreEncryption: true });
    const pages = await mergedPdf.copyPages(donorPdf, donorPdf.getPageIndices());
    pages.forEach((p) => mergedPdf.addPage(p));
  }

  return await mergedPdf.save();
}

/**
 * Split PDF by ranges or single pages
 */
export async function splitPdf(
  file: UploadedFile,
  rangeInput: string
): Promise<{ blob: Blob; isZip: boolean; fileName: string }> {
  const arrayBuffer = await file.file.arrayBuffer();
  const mainPdfDoc = await PDFDocument.load(arrayBuffer, { ignoreEncryption: true });
  const totalPages = mainPdfDoc.getPageCount();

  const ranges = rangeInput.split(',').map((r) => r.trim()).filter(Boolean);
  if (ranges.length === 0) {
    throw new Error('Please enter at least one page range (e.g. 1-2, 3-5)');
  }

  if (ranges.length === 1 && !ranges[0].includes('-')) {
    // Single page split
    const pageNum = parseInt(ranges[0], 10);
    if (isNaN(pageNum) || pageNum < 1 || pageNum > totalPages) {
      throw new Error(`Invalid page number ${ranges[0]}. Document has ${totalPages} pages.`);
    }
    const newPdf = await PDFDocument.create();
    const [copiedPage] = await newPdf.copyPages(mainPdfDoc, [pageNum - 1]);
    newPdf.addPage(copiedPage);
    const bytes = await newPdf.save();
    return {
      blob: new Blob([new Uint8Array(bytes)], { type: 'application/pdf' }),
      isZip: false,
      fileName: `split_page_${pageNum}.pdf`,
    };
  }

  // Multi-range split packaged in ZIP
  const zip = new JSZip();

  for (let i = 0; i < ranges.length; i++) {
    const range = ranges[i];
    const newPdf = await PDFDocument.create();
    let pageIndices: number[] = [];

    if (range.includes('-')) {
      const parts = range.split('-').map((n) => parseInt(n.trim(), 10));
      const start = Math.max(1, parts[0]);
      const end = Math.min(totalPages, parts[1]);
      for (let p = start; p <= end; p++) {
        pageIndices.push(p - 1);
      }
    } else {
      const p = parseInt(range, 10);
      if (!isNaN(p) && p >= 1 && p <= totalPages) {
        pageIndices.push(p - 1);
      }
    }

    if (pageIndices.length > 0) {
      const pages = await newPdf.copyPages(mainPdfDoc, pageIndices);
      pages.forEach((p) => newPdf.addPage(p));
      const bytes = await newPdf.save();
      zip.file(`split_part_${i + 1}_(pages_${range}).pdf`, bytes);
    }
  }

  const zipBlob = await zip.generateAsync({ type: 'blob' });
  return {
    blob: zipBlob,
    isZip: true,
    fileName: `${file.name.replace(/\.pdf$/i, '')}_split_pages.zip`,
  };
}

/**
 * Organize, reorder, and rotate PDF pages
 */
export async function organizePdf(
  file: UploadedFile,
  pageOrder: PageItem[]
): Promise<Uint8Array> {
  const arrayBuffer = await file.file.arrayBuffer();
  const sourcePdf = await PDFDocument.load(arrayBuffer, { ignoreEncryption: true });
  const outputPdf = await PDFDocument.create();

  const activePages = pageOrder.filter((p) => !p.deleted);
  if (activePages.length === 0) {
    throw new Error('All pages have been deleted. Keep at least one page.');
  }

  for (const pageItem of activePages) {
    const [copiedPage] = await outputPdf.copyPages(sourcePdf, [pageItem.pageNumber - 1]);
    if (pageItem.rotation !== 0) {
      const currentRotation = copiedPage.getRotation().angle;
      copiedPage.setRotation(degrees((currentRotation + pageItem.rotation) % 360));
    }
    outputPdf.addPage(copiedPage);
  }

  return await outputPdf.save();
}

/**
 * Convert Images (JPG/PNG/WEBP) to PDF
 */
export async function imagesToPdf(
  files: UploadedFile[],
  orientation: 'auto' | 'portrait' | 'landscape' = 'auto'
): Promise<Uint8Array> {
  const pdfDoc = await PDFDocument.create();

  for (const f of files) {
    const bytes = await f.file.arrayBuffer();
    let image;
    const isPng = f.file.type.includes('png') || f.name.toLowerCase().endsWith('.png');

    if (isPng) {
      image = await pdfDoc.embedPng(bytes);
    } else {
      image = await pdfDoc.embedJpg(bytes);
    }

    let width = image.width;
    let height = image.height;

    if (orientation === 'portrait' && width > height) {
      // Scale into standard portrait letter: 612 x 792
      const scale = Math.min(572 / width, 752 / height);
      width = width * scale;
      height = height * scale;
      const page = pdfDoc.addPage([612, 792]);
      const x = (612 - width) / 2;
      const y = (792 - height) / 2;
      page.drawImage(image, { x, y, width, height });
    } else if (orientation === 'landscape' && height > width) {
      const scale = Math.min(752 / width, 572 / height);
      width = width * scale;
      height = height * scale;
      const page = pdfDoc.addPage([792, 612]);
      const x = (792 - width) / 2;
      const y = (612 - height) / 2;
      page.drawImage(image, { x, y, width, height });
    } else {
      // Match image aspect ratio naturally
      const page = pdfDoc.addPage([width, height]);
      page.drawImage(image, { x: 0, y: 0, width, height });
    }
  }

  return await pdfDoc.save();
}

/**
 * Convert PDF to Images (ZIP of JPG or PNG)
 */
export async function pdfToImages(
  file: UploadedFile,
  format: 'jpeg' | 'png' = 'jpeg',
  scale: number = 2.0
): Promise<Blob> {
  const zip = new JSZip();
  const arrayBuffer = await file.file.arrayBuffer();
  const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;

  for (let i = 1; i <= pdf.numPages; i++) {
    const page = await pdf.getPage(i);
    const viewport = page.getViewport({ scale });
    const canvas = document.createElement('canvas');
    const context = canvas.getContext('2d');
    canvas.height = viewport.height;
    canvas.width = viewport.width;

    if (context) {
      await page.render({ canvasContext: context, viewport, canvas } as any).promise;
      const mime = format === 'png' ? 'image/png' : 'image/jpeg';
      const ext = format === 'png' ? 'png' : 'jpg';
      const dataUrl = canvas.toDataURL(mime, 0.92);
      const base64Data = dataUrl.split(',')[1];
      zip.file(`page_${String(i).padStart(3, '0')}.${ext}`, base64Data, { base64: true });
    }
  }

  return await zip.generateAsync({ type: 'blob' });
}

/**
 * Add Watermark to all pages of a PDF
 */
export async function addWatermark(
  file: UploadedFile,
  options: WatermarkOptions
): Promise<Uint8Array> {
  const arrayBuffer = await file.file.arrayBuffer();
  const pdfDoc = await PDFDocument.load(arrayBuffer, { ignoreEncryption: true });
  const font = await pdfDoc.embedFont(StandardFonts.HelveticaBold);
  const pages = pdfDoc.getPages();

  let rgbColor = rgb(0.5, 0.5, 0.5);
  if (options.color === 'red') rgbColor = rgb(0.85, 0.15, 0.15);
  else if (options.color === 'blue') rgbColor = rgb(0.15, 0.35, 0.85);
  else if (options.color === 'black') rgbColor = rgb(0.1, 0.1, 0.1);

  for (const page of pages) {
    const { width, height } = page.getSize();
    const textWidth = font.widthOfTextAtSize(options.text, options.fontSize);

    let x = (width - textWidth) / 2;
    let y = height / 2;
    let rotation = degrees(options.rotation);

    if (options.position === 'bottom') {
      y = 40;
      rotation = degrees(0);
    }

    page.drawText(options.text, {
      x,
      y,
      size: options.fontSize,
      font,
      color: rgbColor,
      opacity: options.opacity,
      rotate: rotation,
    });
  }

  return await pdfDoc.save();
}

/**
 * Add Page Numbers to PDF
 */
export async function addPageNumbers(
  file: UploadedFile,
  options: PageNumberOptions
): Promise<Uint8Array> {
  const arrayBuffer = await file.file.arrayBuffer();
  const pdfDoc = await PDFDocument.load(arrayBuffer, { ignoreEncryption: true });
  const font = await pdfDoc.embedFont(StandardFonts.Helvetica);
  const pages = pdfDoc.getPages();
  const total = pages.length;

  for (let i = 0; i < total; i++) {
    const page = pages[i];
    const { width, height } = page.getSize();
    const current = i + 1;

    let text = `${current} / ${total}`;
    if (options.format === 'page-of-total') {
      text = `Page ${current} of ${total}`;
    } else if (options.format === 'simple-number') {
      text = `${current}`;
    } else if (options.format === 'dash-number') {
      text = `- ${current} -`;
    }

    const textWidth = font.widthOfTextAtSize(text, options.fontSize);
    let x = width - textWidth - 36;
    let y = 24;

    switch (options.position) {
      case 'bottom-center':
        x = (width - textWidth) / 2;
        y = 24;
        break;
      case 'bottom-left':
        x = 36;
        y = 24;
        break;
      case 'bottom-right':
        x = width - textWidth - 36;
        y = 24;
        break;
      case 'top-center':
        x = (width - textWidth) / 2;
        y = height - 36;
        break;
      case 'top-right':
        x = width - textWidth - 36;
        y = height - 36;
        break;
    }

    page.drawText(text, {
      x,
      y,
      size: options.fontSize,
      font,
      color: rgb(0.3, 0.3, 0.3),
    });
  }

  return await pdfDoc.save();
}

/**
 * Update Metadata & Protect PDF
 */
export async function protectPdf(
  file: UploadedFile,
  meta: { title?: string; author?: string; subject?: string; keywords?: string }
): Promise<Uint8Array> {
  const arrayBuffer = await file.file.arrayBuffer();
  const pdfDoc = await PDFDocument.load(arrayBuffer, { ignoreEncryption: true });

  if (meta.title) pdfDoc.setTitle(meta.title);
  if (meta.author) pdfDoc.setAuthor(meta.author);
  if (meta.subject) pdfDoc.setSubject(meta.subject);
  if (meta.keywords) pdfDoc.setKeywords(meta.keywords.split(',').map((k) => k.trim()));
  pdfDoc.setProducer('PDF Toolkit Private Client');
  pdfDoc.setCreator('PDF Toolkit');

  return await pdfDoc.save();
}

/**
 * Convert PDF to Word (.docx)
 * Extracts structured text, coordinates, headings, lines, and paragraphs,
 * then packages into a genuine Microsoft Word (.docx) document.
 */
export async function convertPdfToWord(
  file: UploadedFile,
  options: { preserveHeadings: boolean; includePageBreaks: boolean } = {
    preserveHeadings: true,
    includePageBreaks: true,
  }
): Promise<{ blob: Blob; textSummary: string; pageCount: number; fileName: string }> {
  const arrayBuffer = await file.file.arrayBuffer();
  const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
  const numPages = pdf.numPages;

  const docxParagraphs: Paragraph[] = [];
  const textSummaryList: string[] = [];

  for (let pageNum = 1; pageNum <= numPages; pageNum++) {
    const page = await pdf.getPage(pageNum);
    const textContent = await page.getTextContent();

    // Group text items into lines based on Y-coordinate
    interface TextItemInfo {
      str: string;
      x: number;
      y: number;
      height: number;
      width: number;
      fontName: string;
    }

    const items: TextItemInfo[] = [];

    for (const item of textContent.items) {
      if ('str' in item && item.str.trim()) {
        const tx = item.transform; // [scaleX, skewY, skewX, scaleY, transX, transY]
        const height = Math.abs(tx[3]) || Math.abs(tx[0]) || 12;
        items.push({
          str: item.str,
          x: tx[4],
          y: tx[5],
          height,
          width: item.width || 0,
          fontName: item.fontName || '',
        });
      }
    }

    // Sort items top-to-bottom (descending Y), then left-to-right (ascending X)
    items.sort((a, b) => {
      const yDiff = Math.abs(a.y - b.y);
      if (yDiff < 4) {
        return a.x - b.x;
      }
      return b.y - a.y; // Higher Y coordinate is higher on the page in PDF
    });

    // Group into physical lines
    interface LineGroup {
      y: number;
      items: TextItemInfo[];
      text: string;
      avgHeight: number;
    }

    const lines: LineGroup[] = [];
    let currentLine: LineGroup | null = null;

    for (const item of items) {
      if (!currentLine || Math.abs(currentLine.y - item.y) > 4) {
        currentLine = {
          y: item.y,
          items: [item],
          text: item.str,
          avgHeight: item.height,
        };
        lines.push(currentLine);
      } else {
        currentLine.items.push(item);
        currentLine.text += ' ' + item.str;
        currentLine.avgHeight = (currentLine.avgHeight + item.height) / 2;
      }
    }

    // Process lines into paragraphs
    let currentParagraphLines: string[] = [];
    let isHeading = false;
    let headingLevel: typeof HeadingLevel.HEADING_1 | typeof HeadingLevel.HEADING_2 | null = null;

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      const trimmedText = line.text.trim();
      if (!trimmedText) continue;

      // Check if line represents a heading based on font height
      const isLargeFont = line.avgHeight >= 15;
      const isMediumFont = line.avgHeight >= 13 && line.avgHeight < 15;

      if (options.preserveHeadings && (isLargeFont || isMediumFont) && trimmedText.length < 90) {
        // Flush previous paragraph
        if (currentParagraphLines.length > 0) {
          const bodyText = currentParagraphLines.join(' ');
          docxParagraphs.push(
            new Paragraph({
              children: [new TextRun({ text: bodyText, size: 24 })], // 24 = 12pt in half-points
              spacing: { after: 160, line: 276 },
            })
          );
          textSummaryList.push(bodyText);
          currentParagraphLines = [];
        }

        // Add Heading
        docxParagraphs.push(
          new Paragraph({
            text: trimmedText,
            heading: isLargeFont ? HeadingLevel.HEADING_1 : HeadingLevel.HEADING_2,
            spacing: { before: 240, after: 120 },
          })
        );
        textSummaryList.push(`[Heading] ${trimmedText}`);
      } else {
        currentParagraphLines.push(trimmedText);

        // Check if paragraph breaks naturally (next line has large vertical gap or starts with bullet)
        const nextLine = lines[i + 1];
        const isLastLine = i === lines.length - 1;
        const largeGap = nextLine && Math.abs(line.y - nextLine.y) > line.avgHeight * 2;
        const isBullet = trimmedText.startsWith('•') || trimmedText.startsWith('-') || /^\d+\./.test(trimmedText);

        if (isLastLine || largeGap || isBullet) {
          const bodyText = currentParagraphLines.join(' ');
          docxParagraphs.push(
            new Paragraph({
              children: [new TextRun({ text: bodyText, size: 24 })],
              spacing: { after: 160, line: 276 },
            })
          );
          textSummaryList.push(bodyText);
          currentParagraphLines = [];
        }
      }
    }

    // Flush any remaining lines on this page
    if (currentParagraphLines.length > 0) {
      const bodyText = currentParagraphLines.join(' ');
      docxParagraphs.push(
        new Paragraph({
          children: [new TextRun({ text: bodyText, size: 24 })],
          spacing: { after: 160, line: 276 },
        })
      );
      textSummaryList.push(bodyText);
    }

    // Insert page break between pages if requested
    if (options.includePageBreaks && pageNum < numPages) {
      docxParagraphs.push(
        new Paragraph({
          children: [new PageBreak()],
        })
      );
    }
  }

  // Fallback if empty
  if (docxParagraphs.length === 0) {
    docxParagraphs.push(
      new Paragraph({
        children: [new TextRun({ text: 'Converted from PDF: No selectable text found (image-only PDF).', italics: true })],
      })
    );
  }

  // Create document
  const doc = new Document({
    sections: [
      {
        properties: {},
        children: docxParagraphs,
      },
    ],
  });

  const docxBlob = await Packer.toBlob(doc);
  const baseName = file.name.replace(/\.pdf$/i, '');

  return {
    blob: docxBlob,
    textSummary: textSummaryList.slice(0, 15).join('\n\n'),
    pageCount: numPages,
    fileName: `${baseName}.docx`,
  };
}

/**
 * Convert Word (.docx) to PDF
 * Converts document HTML styles to formatted vector PDF pages.
 */
export async function convertWordToPdf(
  file: UploadedFile,
  options: { pageSize: 'a4' | 'letter'; margins: 'normal' | 'narrow' | 'wide' } = {
    pageSize: 'a4',
    margins: 'normal',
  }
): Promise<{ blob: Blob; fileName: string; pageCount: number }> {
  const arrayBuffer = await file.file.arrayBuffer();
  const mammothResult = await mammoth.convertToHtml({ arrayBuffer });
  const htmlContent = mammothResult.value;

  // Create isolated container for rendering styled document
  const renderContainer = document.createElement('div');
  renderContainer.id = 'docx-pdf-render-target';
  renderContainer.style.position = 'fixed';
  renderContainer.style.top = '-9999px';
  renderContainer.style.left = '-9999px';
  renderContainer.style.width = '794px'; // standard A4 @ 96 DPI
  renderContainer.style.backgroundColor = '#ffffff';
  renderContainer.style.color = '#111827';
  renderContainer.style.fontFamily = "'Plus Jakarta Sans', 'Segoe UI', Arial, sans-serif";
  renderContainer.style.fontSize = '14px';
  renderContainer.style.lineHeight = '1.6';
  renderContainer.style.padding = options.margins === 'narrow' ? '30px' : options.margins === 'wide' ? '60px' : '45px';
  renderContainer.style.boxSizing = 'border-box';

  // Inject standard clean styling for converted word elements
  renderContainer.innerHTML = `
    <style>
      #docx-pdf-render-target h1 { font-size: 26px; font-weight: 700; margin-top: 24px; margin-bottom: 12px; color: #0f172a; border-bottom: 1px solid #e2e8f0; padding-bottom: 6px; }
      #docx-pdf-render-target h2 { font-size: 20px; font-weight: 600; margin-top: 18px; margin-bottom: 10px; color: #1e293b; }
      #docx-pdf-render-target h3 { font-size: 16px; font-weight: 600; margin-top: 14px; margin-bottom: 8px; color: #334155; }
      #docx-pdf-render-target p { margin-top: 0; margin-bottom: 12px; }
      #docx-pdf-render-target ul { margin-top: 0; margin-bottom: 12px; padding-left: 24px; list-style-type: disc; }
      #docx-pdf-render-target ol { margin-top: 0; margin-bottom: 12px; padding-left: 24px; list-style-type: decimal; }
      #docx-pdf-render-target li { margin-bottom: 4px; }
      #docx-pdf-render-target table { width: 100%; border-collapse: collapse; margin-top: 14px; margin-bottom: 16px; font-size: 13px; }
      #docx-pdf-render-target th, #docx-pdf-render-target td { border: 1px solid #cbd5e1; padding: 8px 10px; text-align: left; }
      #docx-pdf-render-target th { background-color: #f1f5f9; font-weight: 600; }
      #docx-pdf-render-target blockquote { border-left: 3px solid #94a3b8; padding-left: 12px; margin-left: 0; color: #475569; font-style: italic; }
      #docx-pdf-render-target img { max-width: 100%; height: auto; margin: 12px 0; border-radius: 4px; }
    </style>
    <div>
      ${htmlContent || '<p>Empty Word Document</p>'}
    </div>
  `;

  document.body.appendChild(renderContainer);

  try {
    const pdf = new jsPDF({
      orientation: 'portrait',
      unit: 'pt',
      format: options.pageSize === 'letter' ? 'letter' : 'a4',
    });

    const marginPt = options.margins === 'narrow' ? 24 : options.margins === 'wide' ? 54 : 36;
    const pageWidthPt = options.pageSize === 'letter' ? 612 : 595.28;
    const contentWidthPt = pageWidthPt - marginPt * 2;

    await pdf.html(renderContainer, {
      callback: () => {},
      margin: [marginPt, marginPt, marginPt, marginPt],
      autoPaging: 'text',
      width: contentWidthPt,
      windowWidth: 794,
    });

    const pageCount = pdf.getNumberOfPages();
    const pdfBlob = pdf.output('blob');
    const baseName = file.name.replace(/\.docx?$/i, '');

    return {
      blob: pdfBlob,
      fileName: `${baseName}.pdf`,
      pageCount,
    };
  } finally {
    if (renderContainer.parentNode) {
      renderContainer.parentNode.removeChild(renderContainer);
    }
  }
}

/**
 * Trigger browser file download
 */
export function downloadBlob(data: Blob | Uint8Array, filename: string, mimeType: string = 'application/pdf') {
  const blob = data instanceof Blob ? data : new Blob([new Uint8Array(data)], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
