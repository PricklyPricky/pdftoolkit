export type ToolId =
  | 'home'
  | 'pdf-to-word'
  | 'word-to-pdf'
  | 'merge'
  | 'split'
  | 'reorder'
  | 'img-to-pdf'
  | 'pdf-to-img'
  | 'watermark'
  | 'page-numbers'
  | 'protect';

export interface ToolDef {
  id: ToolId;
  name: string;
  iconName: string;
  desc: string;
  accept: string;
  category: 'convert' | 'organize' | 'edit' | 'security';
  badge?: string;
  popular?: boolean;
}

export interface UploadedFile {
  id: string;
  file: File;
  name: string;
  sizeFormatted: string;
  rawSize: number;
  pageCount: number;
  thumbnails: string[];
  pages?: PageItem[];
  wordHtml?: string;
  extractedText?: string;
}

export interface PageItem {
  pageNumber: number; // 1-indexed original page
  rotation: number; // 0, 90, 180, 270
  thumbnail: string;
  deleted?: boolean;
}

export interface WatermarkOptions {
  text: string;
  opacity: number;
  fontSize: number;
  color: string;
  rotation: number;
  position: 'center' | 'diagonal' | 'bottom';
}

export interface PageNumberOptions {
  position: 'bottom-center' | 'bottom-right' | 'bottom-left' | 'top-center' | 'top-right';
  format: 'page-of-total' | 'simple-number' | 'dash-number';
  fontSize: number;
}

export interface SplitOptions {
  mode: 'range' | 'all' | 'custom';
  rangeInput: string;
}

export interface PdfToWordOptions {
  preserveHeadings: boolean;
  detectParagraphs: boolean;
  includePageBreaks: boolean;
}

export interface WordToPdfOptions {
  pageSize: 'a4' | 'letter';
  margins: 'normal' | 'narrow' | 'wide';
}
