import React, { useRef, useState } from 'react';
import { UploadCloud, FileType, FileText, Image } from 'lucide-react';
import { ToolDef } from '../types';

interface DropzoneProps {
  tool: ToolDef;
  onFilesSelected: (files: FileList | File[]) => void;
  multiple?: boolean;
}

export const Dropzone: React.FC<DropzoneProps> = ({
  tool,
  onFilesSelected,
  multiple = true,
}) => {
  const [isDragOver, setIsDragOver] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragOver(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragOver(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      onFilesSelected(e.dataTransfer.files);
    }
  };

  const isWordTool = tool.id === 'word-to-pdf';
  const isImageTool = tool.id === 'img-to-pdf';

  return (
    <div
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
      className={`border-2 border-dashed rounded-2xl p-8 md:p-14 text-center transition-all duration-200 ${
        isDragOver
          ? 'border-red-500 bg-red-50/60 dark:bg-red-950/20 scale-[1.01]'
          : 'border-slate-300 dark:border-slate-700 bg-white/50 dark:bg-slate-800/40 hover:border-slate-400 dark:hover:border-slate-600'
      }`}
    >
      <input
        ref={fileInputRef}
        type="file"
        multiple={multiple}
        accept={tool.accept}
        className="hidden"
        onChange={(e) => {
          if (e.target.files && e.target.files.length > 0) {
            onFilesSelected(e.target.files);
          }
        }}
      />

      <div className="flex flex-col items-center max-w-md mx-auto">
        <div className="w-16 h-16 bg-red-100 dark:bg-red-900/30 text-red-500 dark:text-red-400 rounded-2xl flex items-center justify-center mb-5 shadow-sm">
          {isWordTool ? (
            <FileType className="w-8 h-8" />
          ) : isImageTool ? (
            <Image className="w-8 h-8" />
          ) : (
            <UploadCloud className="w-8 h-8" />
          )}
        </div>

        <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-2">
          {isWordTool
            ? 'Select Word Document (.docx)'
            : isImageTool
            ? 'Select Images (JPG, PNG, WebP)'
            : 'Select PDF files or drag & drop'}
        </h3>

        <p className="text-sm text-slate-500 dark:text-slate-400 mb-6">
          {isWordTool
            ? 'Upload Microsoft Word document to convert to PDF'
            : isImageTool
            ? 'Select one or more images to package into PDF'
            : 'Processed locally in your browser. Files never leave your device.'}
        </p>

        <button
          type="button"
          onClick={() => fileInputRef.current?.click()}
          className="bg-red-500 hover:bg-red-600 active:scale-95 text-white px-8 py-3 rounded-xl font-semibold text-sm shadow-md shadow-red-500/20 hover:shadow-lg transition-all"
        >
          {isWordTool ? 'Choose Word Document' : isImageTool ? 'Choose Images' : 'Choose Files'}
        </button>

        <p className="text-xs text-slate-400 dark:text-slate-500 mt-4">
          {isWordTool ? 'Supports .docx format' : isImageTool ? 'JPG, PNG, WebP supported' : 'PDF files supported up to 100MB'}
        </p>
      </div>
    </div>
  );
};
