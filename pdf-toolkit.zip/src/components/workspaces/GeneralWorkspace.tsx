import React, { useState, useRef } from 'react';
import {
  Download,
  Plus,
  Scissors,
  Combine,
  Stamp,
  ListOrdered,
  Lock,
  Image as ImageIcon,
  Sliders,
  CheckCircle,
} from 'lucide-react';
import {
  UploadedFile,
  ToolId,
  WatermarkOptions,
  PageNumberOptions,
} from '../../types';
import { FileCard } from '../FileCard';
import {
  mergePdfs,
  splitPdf,
  imagesToPdf,
  pdfToImages,
  addWatermark,
  addPageNumbers,
  protectPdf,
  downloadBlob,
} from '../../utils/pdfHelpers';

interface GeneralWorkspaceProps {
  toolId: ToolId;
  files: UploadedFile[];
  onRemoveFile: (index: number) => void;
  onMoveLeft: (index: number) => void;
  onMoveRight: (index: number) => void;
  onAddMoreFiles: (files: FileList | File[]) => void;
  onReset: () => void;
  setLoading: (loading: boolean, text?: string) => void;
  showToast: (msg: string, type?: 'success' | 'error') => void;
}

export const GeneralWorkspace: React.FC<GeneralWorkspaceProps> = ({
  toolId,
  files,
  onRemoveFile,
  onMoveLeft,
  onMoveRight,
  onAddMoreFiles,
  onReset,
  setLoading,
  showToast,
}) => {
  const addFileInputRef = useRef<HTMLInputElement>(null);

  // Split state
  const [splitRange, setSplitRange] = useState('1-2, 3-5');

  // Images to PDF state
  const [imageOrientation, setImageOrientation] = useState<'auto' | 'portrait' | 'landscape'>('auto');

  // PDF to Images state
  const [imageFormat, setImageFormat] = useState<'jpeg' | 'png'>('jpeg');
  const [imageScale, setImageScale] = useState<number>(2.0);

  // Watermark state
  const [watermark, setWatermark] = useState<WatermarkOptions>({
    text: 'CONFIDENTIAL',
    opacity: 0.5,
    fontSize: 48,
    color: 'gray',
    rotation: 45,
    position: 'diagonal',
  });

  // Page numbers state
  const [pageNumbers, setPageNumbers] = useState<PageNumberOptions>({
    position: 'bottom-center',
    format: 'page-of-total',
    fontSize: 10,
  });

  // Protect & metadata state
  const [metaTitle, setMetaTitle] = useState(files[0]?.name.replace(/\.pdf$/i, '') || '');
  const [metaAuthor, setMetaAuthor] = useState('');
  const [metaSubject, setMetaSubject] = useState('');
  const [metaKeywords, setMetaKeywords] = useState('');

  // Primary action executor
  const handleExecuteAction = async () => {
    if (files.length === 0) return;

    try {
      if (toolId === 'merge') {
        if (files.length < 2) {
          showToast('Please add at least 2 PDF files to merge.', 'error');
          return;
        }
        setLoading(true, 'Merging PDF documents...');
        const bytes = await mergePdfs(files);
        downloadBlob(bytes, 'merged_toolkit.pdf');
        showToast('Files merged successfully!');
      } else if (toolId === 'split') {
        if (!splitRange.trim()) {
          showToast('Please enter at least one range or page number.', 'error');
          return;
        }
        setLoading(true, 'Splitting PDF pages...');
        const result = await splitPdf(files[0], splitRange);
        downloadBlob(result.blob, result.fileName, result.isZip ? 'application/zip' : 'application/pdf');
        showToast('PDF split successfully!');
      } else if (toolId === 'img-to-pdf') {
        setLoading(true, 'Packaging images into PDF...');
        const bytes = await imagesToPdf(files, imageOrientation);
        downloadBlob(bytes, 'images_to_pdf.pdf');
        showToast('Images converted to PDF successfully!');
      } else if (toolId === 'pdf-to-img') {
        setLoading(true, `Extracting pages as high-resolution ${imageFormat.toUpperCase()} images...`);
        const zipBlob = await pdfToImages(files[0], imageFormat, imageScale);
        downloadBlob(zipBlob, `${files[0].name.replace(/\.pdf$/i, '')}_images.zip`, 'application/zip');
        showToast('All pages extracted and downloaded as ZIP!');
      } else if (toolId === 'watermark') {
        setLoading(true, 'Applying watermark across all pages...');
        const bytes = await addWatermark(files[0], watermark);
        downloadBlob(bytes, `${files[0].name.replace(/\.pdf$/i, '')}_watermarked.pdf`);
        showToast('Watermark added successfully!');
      } else if (toolId === 'page-numbers') {
        setLoading(true, 'Numbering all pages...');
        const bytes = await addPageNumbers(files[0], pageNumbers);
        downloadBlob(bytes, `${files[0].name.replace(/\.pdf$/i, '')}_numbered.pdf`);
        showToast('Page numbers applied successfully!');
      } else if (toolId === 'protect') {
        setLoading(true, 'Updating PDF metadata and properties...');
        const bytes = await protectPdf(files[0], {
          title: metaTitle,
          author: metaAuthor,
          subject: metaSubject,
          keywords: metaKeywords,
        });
        downloadBlob(bytes, `${files[0].name.replace(/\.pdf$/i, '')}_protected.pdf`);
        showToast('Document properties and metadata updated!');
      }
    } catch (err: any) {
      console.error(err);
      showToast(err.message || 'Operation failed. Please check inputs.', 'error');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Hidden file input for adding more files in Merge/Images */}
      <input
        ref={addFileInputRef}
        type="file"
        multiple
        accept={toolId === 'img-to-pdf' ? 'image/*' : '.pdf'}
        className="hidden"
        onChange={(e) => {
          if (e.target.files && e.target.files.length > 0) {
            onAddMoreFiles(e.target.files);
          }
        }}
      />

      {/* Top action header */}
      <div className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 p-5 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h3 className="font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <span>{files.length} {files.length === 1 ? 'File' : 'Files'} Selected</span>
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            {toolId === 'merge'
              ? 'Arrange the documents in the exact order you want them merged.'
              : toolId === 'split'
              ? 'Specify page numbers or ranges to extract.'
              : 'Configure tool settings and download your processed PDF.'}
          </p>
        </div>

        <div className="flex items-center gap-3">
          {(toolId === 'merge' || toolId === 'img-to-pdf') && (
            <button
              onClick={() => addFileInputRef.current?.click()}
              className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 rounded-xl transition-colors"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add More Files</span>
            </button>
          )}

          <button
            onClick={onReset}
            className="px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-xl transition-colors"
          >
            Clear All
          </button>

          <button
            onClick={handleExecuteAction}
            className="flex items-center gap-2 bg-red-500 hover:bg-red-600 active:scale-95 text-white px-6 py-2.5 rounded-xl font-bold text-xs shadow-md shadow-red-500/20 transition-all"
          >
            <Download className="w-4 h-4" />
            <span>
              {toolId === 'merge'
                ? 'Merge PDFs'
                : toolId === 'split'
                ? 'Split & Download'
                : toolId === 'img-to-pdf'
                ? 'Convert to PDF'
                : toolId === 'pdf-to-img'
                ? 'Extract Images (ZIP)'
                : toolId === 'watermark'
                ? 'Apply Watermark'
                : toolId === 'page-numbers'
                ? 'Add Page Numbers'
                : 'Save Document'}
            </span>
          </button>
        </div>
      </div>

      {/* Main workspace layout */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Settings Column */}
        {toolId !== 'merge' && (
          <div className="space-y-4">
            <div className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 p-5 shadow-sm space-y-4">
              <h4 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                <Sliders className="w-4 h-4 text-red-500" />
                <span>Options & Settings</span>
              </h4>

              {/* Split Settings */}
              {toolId === 'split' && (
                <div className="space-y-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Page Ranges to Extract
                    </label>
                    <input
                      type="text"
                      value={splitRange}
                      onChange={(e) => setSplitRange(e.target.value)}
                      placeholder="e.g. 1-2, 3-5 or 1"
                      className="w-full p-2.5 text-xs bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white"
                    />
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
                      Separate ranges with commas. Example: <code className="bg-slate-100 dark:bg-slate-800 px-1 py-0.5 rounded">1-3, 5, 7-10</code>
                    </p>
                  </div>
                  <div className="text-[11px] text-slate-500 dark:text-slate-400 bg-slate-50 dark:bg-slate-900 p-3 rounded-lg">
                    Total pages in document: <strong className="text-slate-800 dark:text-slate-200">{files[0]?.pageCount || 1}</strong>
                  </div>
                </div>
              )}

              {/* Images to PDF Settings */}
              {toolId === 'img-to-pdf' && (
                <div className="space-y-3">
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                    Page Orientation
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    {(['auto', 'portrait', 'landscape'] as const).map((orient) => (
                      <button
                        key={orient}
                        type="button"
                        onClick={() => setImageOrientation(orient)}
                        className={`py-2 text-xs font-medium rounded-lg border capitalize text-center transition-all ${
                          imageOrientation === orient
                            ? 'border-red-500 bg-red-50 dark:bg-red-950/40 text-red-600 dark:text-red-400 font-bold'
                            : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-700'
                        }`}
                      >
                        {orient}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* PDF to Images Settings */}
              {toolId === 'pdf-to-img' && (
                <div className="space-y-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                      Output Format
                    </label>
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        type="button"
                        onClick={() => setImageFormat('jpeg')}
                        className={`py-2 text-xs font-medium rounded-lg border text-center transition-all ${
                          imageFormat === 'jpeg'
                            ? 'border-red-500 bg-red-50 dark:bg-red-950/40 text-red-600 dark:text-red-400 font-bold'
                            : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-700'
                        }`}
                      >
                        JPG (Smaller size)
                      </button>
                      <button
                        type="button"
                        onClick={() => setImageFormat('png')}
                        className={`py-2 text-xs font-medium rounded-lg border text-center transition-all ${
                          imageFormat === 'png'
                            ? 'border-red-500 bg-red-50 dark:bg-red-950/40 text-red-600 dark:text-red-400 font-bold'
                            : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-700'
                        }`}
                      >
                        PNG (Lossless)
                      </button>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                      Resolution Quality
                    </label>
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        type="button"
                        onClick={() => setImageScale(1.5)}
                        className={`py-2 text-xs font-medium rounded-lg border text-center transition-all ${
                          imageScale === 1.5
                            ? 'border-red-500 bg-red-50 dark:bg-red-950/40 text-red-600 dark:text-red-400 font-bold'
                            : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-700'
                        }`}
                      >
                        Standard 150 DPI
                      </button>
                      <button
                        type="button"
                        onClick={() => setImageScale(2.5)}
                        className={`py-2 text-xs font-medium rounded-lg border text-center transition-all ${
                          imageScale === 2.5
                            ? 'border-red-500 bg-red-50 dark:bg-red-950/40 text-red-600 dark:text-red-400 font-bold'
                            : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-700'
                        }`}
                      >
                        High-Res 300 DPI
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* Watermark Settings */}
              {toolId === 'watermark' && (
                <div className="space-y-3.5">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Watermark Text
                    </label>
                    <input
                      type="text"
                      value={watermark.text}
                      onChange={(e) => setWatermark({ ...watermark, text: e.target.value })}
                      className="w-full p-2.5 text-xs bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white"
                    />
                  </div>

                  <div>
                    <div className="flex justify-between text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      <span>Opacity</span>
                      <span>{Math.round(watermark.opacity * 100)}%</span>
                    </div>
                    <input
                      type="range"
                      min="0.1"
                      max="1.0"
                      step="0.05"
                      value={watermark.opacity}
                      onChange={(e) => setWatermark({ ...watermark, opacity: parseFloat(e.target.value) })}
                      className="w-full accent-red-500"
                    />
                  </div>

                  <div>
                    <div className="flex justify-between text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      <span>Font Size</span>
                      <span>{watermark.fontSize}px</span>
                    </div>
                    <input
                      type="range"
                      min="20"
                      max="80"
                      step="4"
                      value={watermark.fontSize}
                      onChange={(e) => setWatermark({ ...watermark, fontSize: parseInt(e.target.value, 10) })}
                      className="w-full accent-red-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                      Color
                    </label>
                    <div className="grid grid-cols-4 gap-2">
                      {(['gray', 'red', 'blue', 'black'] as const).map((col) => (
                        <button
                          key={col}
                          type="button"
                          onClick={() => setWatermark({ ...watermark, color: col })}
                          className={`py-1.5 text-xs font-medium rounded-lg border capitalize text-center transition-all ${
                            watermark.color === col
                              ? 'border-red-500 bg-red-50 dark:bg-red-950/40 text-red-600 dark:text-red-400 font-bold'
                              : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400'
                          }`}
                        >
                          {col}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* Page Numbers Settings */}
              {toolId === 'page-numbers' && (
                <div className="space-y-3.5">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                      Position on Page
                    </label>
                    <select
                      value={pageNumbers.position}
                      onChange={(e) => setPageNumbers({ ...pageNumbers, position: e.target.value as any })}
                      className="w-full p-2.5 text-xs bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white"
                    >
                      <option value="bottom-center">Bottom Center</option>
                      <option value="bottom-right">Bottom Right</option>
                      <option value="bottom-left">Bottom Left</option>
                      <option value="top-center">Top Center</option>
                      <option value="top-right">Top Right</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                      Numbering Format
                    </label>
                    <div className="space-y-2">
                      {[
                        { id: 'page-of-total', label: 'Page 1 of 5' },
                        { id: 'simple-number', label: '1 / 5' },
                        { id: 'dash-number', label: '- 1 -' },
                      ].map((fmt) => (
                        <label
                          key={fmt.id}
                          className="flex items-center gap-2.5 p-2 rounded-lg border border-slate-200 dark:border-slate-700 cursor-pointer text-xs"
                        >
                          <input
                            type="radio"
                            name="pageFmt"
                            checked={pageNumbers.format === fmt.id}
                            onChange={() => setPageNumbers({ ...pageNumbers, format: fmt.id as any })}
                            className="text-red-500 focus:ring-red-400"
                          />
                          <span className="font-medium text-slate-800 dark:text-slate-200">{fmt.label}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* Protect & Metadata Settings */}
              {toolId === 'protect' && (
                <div className="space-y-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Document Title
                    </label>
                    <input
                      type="text"
                      value={metaTitle}
                      onChange={(e) => setMetaTitle(e.target.value)}
                      className="w-full p-2.5 text-xs bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Author / Organization
                    </label>
                    <input
                      type="text"
                      value={metaAuthor}
                      onChange={(e) => setMetaAuthor(e.target.value)}
                      placeholder="e.g. Acme Legal Corp"
                      className="w-full p-2.5 text-xs bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Subject
                    </label>
                    <input
                      type="text"
                      value={metaSubject}
                      onChange={(e) => setMetaSubject(e.target.value)}
                      className="w-full p-2.5 text-xs bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Keywords
                    </label>
                    <input
                      type="text"
                      value={metaKeywords}
                      onChange={(e) => setMetaKeywords(e.target.value)}
                      placeholder="e.g. confidential, contract, v1"
                      className="w-full p-2.5 text-xs bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white"
                    />
                  </div>
                </div>
              )}

              {/* Action Button */}
              <button
                onClick={handleExecuteAction}
                className="w-full flex items-center justify-center gap-2 bg-red-500 hover:bg-red-600 text-white font-bold text-xs py-3 px-4 rounded-xl shadow-md shadow-red-500/20 active:scale-98 transition-all"
              >
                <Download className="w-4 h-4" />
                <span>Process & Download</span>
              </button>
            </div>
          </div>
        )}

        {/* Files Grid Column */}
        <div className={toolId === 'merge' ? 'col-span-full' : 'lg:col-span-2'}>
          <div className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 p-5 shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <h4 className="font-bold text-sm text-slate-900 dark:text-white">
                {toolId === 'merge'
                  ? 'Reorder PDFs for Merging'
                  : 'Document Preview'}
              </h4>
              <span className="text-xs text-slate-500">
                {files.length} {files.length === 1 ? 'file' : 'files'}
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
              {files.map((file, idx) => (
                <FileCard
                  key={file.id}
                  file={file}
                  index={idx}
                  totalFiles={files.length}
                  onRemove={onRemoveFile}
                  onMoveLeft={onMoveLeft}
                  onMoveRight={onMoveRight}
                  showReorder={toolId === 'merge'}
                />
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
