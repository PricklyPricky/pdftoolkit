import React, { useState } from 'react';
import {
  RotateCw,
  Trash2,
  Undo2,
  Download,
  LayoutGrid,
  ChevronLeft,
  ChevronRight,
  AlertCircle,
} from 'lucide-react';
import { UploadedFile, PageItem } from '../../types';
import { organizePdf, downloadBlob } from '../../utils/pdfHelpers';

interface OrganizeWorkspaceProps {
  file: UploadedFile;
  onReset: () => void;
  setLoading: (loading: boolean, text?: string) => void;
  showToast: (msg: string, type?: 'success' | 'error') => void;
}

export const OrganizeWorkspace: React.FC<OrganizeWorkspaceProps> = ({
  file,
  onReset,
  setLoading,
  showToast,
}) => {
  const [pages, setPages] = useState<PageItem[]>(file.pages || []);

  const handleRotate = (index: number) => {
    setPages((prev) => {
      const updated = [...prev];
      const current = updated[index];
      updated[index] = {
        ...current,
        rotation: (current.rotation + 90) % 360,
      };
      return updated;
    });
  };

  const handleToggleDelete = (index: number) => {
    setPages((prev) => {
      const updated = [...prev];
      updated[index] = {
        ...updated[index],
        deleted: !updated[index].deleted,
      };
      return updated;
    });
  };

  const handleMove = (index: number, direction: 'left' | 'right') => {
    const targetIndex = direction === 'left' ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= pages.length) return;

    setPages((prev) => {
      const updated = [...prev];
      const item = updated.splice(index, 1)[0];
      updated.splice(targetIndex, 0, item);
      return updated;
    });
  };

  const handleSave = async () => {
    const activeCount = pages.filter((p) => !p.deleted).length;
    if (activeCount === 0) {
      showToast('Cannot save: All pages have been deleted.', 'error');
      return;
    }

    try {
      setLoading(true, 'Reordering and rotating pages...');
      const bytes = await organizePdf(file, pages);
      downloadBlob(bytes, `${file.name.replace(/\.pdf$/i, '')}_organized.pdf`);
      showToast('Organized PDF downloaded successfully!');
    } catch (err: any) {
      console.error(err);
      showToast(err.message || 'Failed to save organized PDF', 'error');
    } finally {
      setLoading(false);
    }
  };

  const activePagesCount = pages.filter((p) => !p.deleted).length;

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 p-5 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h3 className="font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <span>{file.name}</span>
            <span className="text-xs font-normal text-slate-500">
              ({activePagesCount} of {pages.length} pages kept)
            </span>
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Rotate individual pages, reorder by moving, or remove unwanted pages.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={onReset}
            className="px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-xl transition-colors"
          >
            Change File
          </button>
          <button
            onClick={handleSave}
            disabled={activePagesCount === 0}
            className="flex items-center gap-2 bg-red-500 hover:bg-red-600 active:scale-95 text-white px-5 py-2.5 rounded-xl font-bold text-xs shadow-md shadow-red-500/20 disabled:opacity-50 transition-all"
          >
            <Download className="w-4 h-4" />
            <span>Save & Download PDF</span>
          </button>
        </div>
      </div>

      {/* Pages Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
        {pages.map((page, index) => {
          return (
            <div
              key={`${page.pageNumber}-${index}`}
              className={`relative bg-white dark:bg-slate-800 rounded-xl border p-2.5 shadow-sm transition-all flex flex-col ${
                page.deleted
                  ? 'opacity-40 border-dashed border-red-300 dark:border-red-900 bg-red-50/20'
                  : 'border-slate-200 dark:border-slate-700 hover:shadow-md'
              }`}
            >
              <div className="flex items-center justify-between mb-1.5 text-[11px] font-bold">
                <span className="text-slate-500 dark:text-slate-400">
                  Page {page.pageNumber}
                </span>
                {page.rotation !== 0 && (
                  <span className="text-amber-500 text-[10px]">
                    {page.rotation}°
                  </span>
                )}
              </div>

              {/* Page Thumbnail with Rotation */}
              <div className="aspect-[3/4] bg-slate-100 dark:bg-slate-900 rounded-lg overflow-hidden flex items-center justify-center relative mb-2">
                {page.thumbnail ? (
                  <img
                    src={page.thumbnail}
                    alt={`Page ${page.pageNumber}`}
                    style={{ transform: `rotate(${page.rotation}deg)` }}
                    className="w-full h-full object-contain transition-transform duration-200"
                  />
                ) : (
                  <LayoutGrid className="w-6 h-6 text-slate-300" />
                )}

                {page.deleted && (
                  <div className="absolute inset-0 bg-red-500/20 backdrop-blur-[1px] flex items-center justify-center">
                    <span className="bg-red-500 text-white font-bold text-[10px] px-2 py-0.5 rounded">
                      DELETED
                    </span>
                  </div>
                )}
              </div>

              {/* Action Controls */}
              <div className="flex items-center justify-between gap-1 pt-1 border-t border-slate-100 dark:border-slate-700/60 mt-auto">
                <button
                  type="button"
                  onClick={() => handleMove(index, 'left')}
                  disabled={index === 0}
                  className="p-1 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 disabled:opacity-20"
                  title="Move left"
                >
                  <ChevronLeft className="w-3.5 h-3.5" />
                </button>

                <button
                  type="button"
                  onClick={() => handleRotate(index)}
                  className="p-1 text-slate-500 hover:text-slate-900 dark:hover:text-white"
                  title="Rotate 90°"
                >
                  <RotateCw className="w-3.5 h-3.5" />
                </button>

                <button
                  type="button"
                  onClick={() => handleToggleDelete(index)}
                  className={`p-1 rounded ${
                    page.deleted
                      ? 'text-emerald-500 hover:text-emerald-600'
                      : 'text-slate-400 hover:text-red-500'
                  }`}
                  title={page.deleted ? 'Restore page' : 'Delete page'}
                >
                  {page.deleted ? <Undo2 className="w-3.5 h-3.5" /> : <Trash2 className="w-3.5 h-3.5" />}
                </button>

                <button
                  type="button"
                  onClick={() => handleMove(index, 'right')}
                  disabled={index === pages.length - 1}
                  className="p-1 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 disabled:opacity-20"
                  title="Move right"
                >
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
