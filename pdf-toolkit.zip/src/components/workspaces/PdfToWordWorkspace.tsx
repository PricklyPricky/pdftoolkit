import React, { useState, useEffect } from 'react';
import {
  FileText,
  Download,
  CheckCircle,
  FileCode,
  Layers,
  Sparkles,
  RefreshCw,
  Eye,
} from 'lucide-react';
import { UploadedFile } from '../../types';
import { convertPdfToWord, downloadBlob } from '../../utils/pdfHelpers';

interface PdfToWordWorkspaceProps {
  file: UploadedFile;
  onReset: () => void;
  setLoading: (loading: boolean, text?: string) => void;
  showToast: (msg: string, type?: 'success' | 'error') => void;
}

export const PdfToWordWorkspace: React.FC<PdfToWordWorkspaceProps> = ({
  file,
  onReset,
  setLoading,
  showToast,
}) => {
  const [preserveHeadings, setPreserveHeadings] = useState(true);
  const [includePageBreaks, setIncludePageBreaks] = useState(true);
  const [convertedDoc, setConvertedDoc] = useState<{
    blob: Blob;
    textSummary: string;
    pageCount: number;
    fileName: string;
  } | null>(null);
  const [activeTab, setActiveTab] = useState<'preview' | 'thumbnails'>('preview');

  // Convert on mount or when options change
  const handleConvert = async () => {
    try {
      setLoading(true, 'Extracting text and formatting Word document...');
      const result = await convertPdfToWord(file, {
        preserveHeadings,
        includePageBreaks,
      });
      setConvertedDoc(result);
      showToast('Successfully converted to Word (.docx)! Ready to download.');
    } catch (err: any) {
      console.error(err);
      showToast(err.message || 'Failed to convert PDF to Word', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    handleConvert();
  }, [file]);

  const handleDownload = () => {
    if (!convertedDoc) return;
    downloadBlob(
      convertedDoc.blob,
      convertedDoc.fileName,
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
    );
    showToast('Word document downloaded!');
  };

  return (
    <div className="space-y-6">
      {/* Top Banner Info */}
      <div className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 p-5 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-blue-50 dark:bg-blue-950/40 text-blue-600 dark:text-blue-400 flex items-center justify-center shrink-0">
            <FileText className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-bold text-slate-900 dark:text-white truncate max-w-md">
                {file.name}
              </h3>
              <span className="text-[10px] font-bold bg-blue-100 dark:bg-blue-950/60 text-blue-700 dark:text-blue-400 px-2 py-0.5 rounded-full">
                PDF
              </span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              {file.pageCount} {file.pageCount === 1 ? 'Page' : 'Pages'} • {file.sizeFormatted}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={onReset}
            className="px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-xl transition-colors"
          >
            Choose Another File
          </button>
          <button
            onClick={handleDownload}
            disabled={!convertedDoc}
            className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 active:scale-95 text-white px-5 py-2.5 rounded-xl font-bold text-xs shadow-md shadow-blue-600/20 disabled:opacity-50 transition-all"
          >
            <Download className="w-4 h-4" />
            <span>Download Word (.docx)</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Conversion Settings & Statistics */}
        <div className="space-y-4">
          <div className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 p-5 shadow-sm">
            <h4 className="font-bold text-sm text-slate-900 dark:text-white mb-4 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-blue-500" />
              <span>Conversion Settings</span>
            </h4>

            <div className="space-y-3.5">
              <label className="flex items-start gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={preserveHeadings}
                  onChange={(e) => setPreserveHeadings(e.target.checked)}
                  className="mt-0.5 h-4 w-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                />
                <div>
                  <span className="text-xs font-semibold text-slate-900 dark:text-white block">
                    Preserve Headings & Titles
                  </span>
                  <span className="text-[11px] text-slate-500 dark:text-slate-400">
                    Detects larger font sizes and formats them as Heading 1 & Heading 2 in Word.
                  </span>
                </div>
              </label>

              <label className="flex items-start gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={includePageBreaks}
                  onChange={(e) => setIncludePageBreaks(e.target.checked)}
                  className="mt-0.5 h-4 w-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                />
                <div>
                  <span className="text-xs font-semibold text-slate-900 dark:text-white block">
                    Keep Page Breaks
                  </span>
                  <span className="text-[11px] text-slate-500 dark:text-slate-400">
                    Adds hard page breaks between pages to mirror the original PDF pagination.
                  </span>
                </div>
              </label>
            </div>

            <div className="mt-5 pt-4 border-t border-slate-100 dark:border-slate-700">
              <button
                onClick={handleConvert}
                className="w-full flex items-center justify-center gap-2 px-4 py-2 text-xs font-semibold text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950/30 hover:bg-blue-100 dark:hover:bg-blue-900/40 rounded-xl transition-colors"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Re-convert with Updated Settings</span>
              </button>
            </div>
          </div>

          {/* Format Spec Box */}
          <div className="bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700/60 p-5">
            <h5 className="text-xs font-bold text-slate-700 dark:text-slate-300 mb-2">
              Microsoft Word Compatibility
            </h5>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
              Generates genuine OpenXML (.docx) files compatible with Microsoft Word 2016+, Office 365, Google Docs, Apple Pages, and LibreOffice.
            </p>
          </div>
        </div>

        {/* Right Column: Extracted Content Preview */}
        <div className="lg:col-span-2 bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 p-5 shadow-sm flex flex-col">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-700 mb-4">
            <div className="flex items-center gap-2">
              <button
                onClick={() => setActiveTab('preview')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                  activeTab === 'preview'
                    ? 'bg-blue-50 text-blue-600 dark:bg-blue-950/50 dark:text-blue-400'
                    : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700'
                }`}
              >
                Extracted Text & Document Structure
              </button>
              <button
                onClick={() => setActiveTab('thumbnails')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                  activeTab === 'thumbnails'
                    ? 'bg-blue-50 text-blue-600 dark:bg-blue-950/50 dark:text-blue-400'
                    : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700'
                }`}
              >
                Original PDF Pages ({file.pageCount})
              </button>
            </div>

            {convertedDoc && (
              <span className="text-[11px] font-medium text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
                <CheckCircle className="w-3.5 h-3.5" />
                <span>Ready to download</span>
              </span>
            )}
          </div>

          {activeTab === 'preview' ? (
            <div className="flex-1 min-h-[360px] max-h-[500px] overflow-y-auto bg-slate-50 dark:bg-slate-900 rounded-xl p-4 font-sans border border-slate-100 dark:border-slate-800">
              {convertedDoc?.textSummary ? (
                <div className="space-y-3 text-xs leading-relaxed text-slate-800 dark:text-slate-200">
                  {convertedDoc.textSummary.split('\n\n').map((para, i) => {
                    if (para.startsWith('[Heading]')) {
                      return (
                        <h4
                          key={i}
                          className="text-sm font-bold text-blue-600 dark:text-blue-400 pt-2"
                        >
                          {para.replace('[Heading] ', '')}
                        </h4>
                      );
                    }
                    return (
                      <p key={i} className="text-slate-700 dark:text-slate-300">
                        {para}
                      </p>
                    );
                  })}
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center h-full text-slate-400 text-xs">
                  <FileCode className="w-8 h-8 mb-2 opacity-50" />
                  <span>Extracting text content from document...</span>
                </div>
              )}
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3 max-h-[500px] overflow-y-auto p-1">
              {file.pages && file.pages.length > 0 ? (
                file.pages.map((p) => (
                  <div
                    key={p.pageNumber}
                    className="border border-slate-200 dark:border-slate-700 rounded-lg p-2 bg-slate-50 dark:bg-slate-900"
                  >
                    <div className="aspect-[3/4] bg-white rounded overflow-hidden mb-1.5 shadow-xs">
                      {p.thumbnail && (
                        <img
                          src={p.thumbnail}
                          alt={`Page ${p.pageNumber}`}
                          className="w-full h-full object-contain"
                        />
                      )}
                    </div>
                    <p className="text-[10px] text-center font-bold text-slate-500">
                      Page {p.pageNumber}
                    </p>
                  </div>
                ))
              ) : (
                <div className="col-span-full py-8 text-center text-xs text-slate-400">
                  No page preview available.
                </div>
              )}
            </div>
          )}

          {/* Action Download Bar at Bottom */}
          <div className="mt-5 pt-4 border-t border-slate-100 dark:border-slate-700 flex items-center justify-between">
            <span className="text-xs text-slate-500 dark:text-slate-400">
              Output: <strong className="text-slate-700 dark:text-slate-200">{convertedDoc?.fileName || `${file.name.replace(/\.pdf$/i, '')}.docx`}</strong>
            </span>
            <button
              onClick={handleDownload}
              disabled={!convertedDoc}
              className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 active:scale-95 text-white px-6 py-2.5 rounded-xl font-bold text-xs shadow-md shadow-blue-600/20 disabled:opacity-50 transition-all"
            >
              <Download className="w-4 h-4" />
              <span>Download .docx File</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
