import React, { useState } from 'react';
import {
  FileType,
  Download,
  CheckCircle,
  FileText,
  Sliders,
  Sparkles,
  BookOpen,
} from 'lucide-react';
import { UploadedFile } from '../../types';
import { convertWordToPdf, downloadBlob } from '../../utils/pdfHelpers';

interface WordToPdfWorkspaceProps {
  file: UploadedFile;
  onReset: () => void;
  setLoading: (loading: boolean, text?: string) => void;
  showToast: (msg: string, type?: 'success' | 'error') => void;
}

export const WordToPdfWorkspace: React.FC<WordToPdfWorkspaceProps> = ({
  file,
  onReset,
  setLoading,
  showToast,
}) => {
  const [pageSize, setPageSize] = useState<'a4' | 'letter'>('a4');
  const [margins, setMargins] = useState<'normal' | 'narrow' | 'wide'>('normal');

  const handleConvertAndDownload = async () => {
    try {
      setLoading(true, 'Rendering Word styles and generating vector PDF...');
      const result = await convertWordToPdf(file, { pageSize, margins });
      downloadBlob(result.blob, result.fileName, 'application/pdf');
      showToast('Word document converted to PDF and downloaded successfully!');
    } catch (err: any) {
      console.error(err);
      showToast(err.message || 'Failed to convert Word document to PDF', 'error');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner Info */}
      <div className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 p-5 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400 flex items-center justify-center shrink-0">
            <FileType className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-bold text-slate-900 dark:text-white truncate max-w-md">
                {file.name}
              </h3>
              <span className="text-[10px] font-bold bg-indigo-100 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-400 px-2 py-0.5 rounded-full">
                DOCX
              </span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Approx. {file.pageCount} {file.pageCount === 1 ? 'Page' : 'Pages'} • {file.sizeFormatted}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={onReset}
            className="px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-xl transition-colors"
          >
            Choose Another File
          </button>
          <button
            onClick={handleConvertAndDownload}
            className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 active:scale-95 text-white px-5 py-2.5 rounded-xl font-bold text-xs shadow-md shadow-indigo-600/20 transition-all"
          >
            <Download className="w-4 h-4" />
            <span>Convert & Download PDF</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: PDF Layout Settings */}
        <div className="space-y-4">
          <div className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 p-5 shadow-sm">
            <h4 className="font-bold text-sm text-slate-900 dark:text-white mb-4 flex items-center gap-2">
              <Sliders className="w-4 h-4 text-indigo-500" />
              <span>PDF Output Settings</span>
            </h4>

            <div className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                  Page Dimensions
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setPageSize('a4')}
                    className={`py-2 px-3 text-xs font-medium rounded-lg border text-center transition-all ${
                      pageSize === 'a4'
                        ? 'border-indigo-600 bg-indigo-50 dark:bg-indigo-950/40 text-indigo-700 dark:text-indigo-300 font-bold'
                        : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-700'
                    }`}
                  >
                    Standard A4 (International)
                  </button>
                  <button
                    type="button"
                    onClick={() => setPageSize('letter')}
                    className={`py-2 px-3 text-xs font-medium rounded-lg border text-center transition-all ${
                      pageSize === 'letter'
                        ? 'border-indigo-600 bg-indigo-50 dark:bg-indigo-950/40 text-indigo-700 dark:text-indigo-300 font-bold'
                        : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-700'
                    }`}
                  >
                    US Letter (8.5 × 11 in)
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                  Page Margins
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {(['normal', 'narrow', 'wide'] as const).map((m) => (
                    <button
                      key={m}
                      type="button"
                      onClick={() => setMargins(m)}
                      className={`py-2 px-2 text-xs font-medium rounded-lg border capitalize text-center transition-all ${
                        margins === m
                          ? 'border-indigo-600 bg-indigo-50 dark:bg-indigo-950/40 text-indigo-700 dark:text-indigo-300 font-bold'
                          : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-700'
                      }`}
                    >
                      {m}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-slate-100 dark:border-slate-700">
              <button
                onClick={handleConvertAndDownload}
                className="w-full flex items-center justify-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs py-3 px-4 rounded-xl shadow-md shadow-indigo-600/20 active:scale-98 transition-all"
              >
                <Download className="w-4 h-4" />
                <span>Generate PDF Document</span>
              </button>
            </div>
          </div>

          <div className="bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700/60 p-5">
            <h5 className="text-xs font-bold text-slate-700 dark:text-slate-300 mb-2 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-indigo-500" />
              <span>Full Styling Preservation</span>
            </h5>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
              Preserves typography, headings, tables, bold, italics, numbered and bulleted lists, and embedded images.
            </p>
          </div>
        </div>

        {/* Right Column: Live Word Document Preview */}
        <div className="lg:col-span-2 bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 p-5 shadow-sm flex flex-col">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-700 mb-4">
            <div className="flex items-center gap-2 text-xs font-bold text-slate-900 dark:text-white">
              <BookOpen className="w-4 h-4 text-indigo-500" />
              <span>Document Content Preview</span>
            </div>
            <span className="text-[11px] text-slate-500 dark:text-slate-400">
              Live Word formatting
            </span>
          </div>

          {/* Rendered HTML document container with clean page simulation */}
          <div className="flex-1 min-h-[420px] max-h-[580px] overflow-y-auto bg-slate-100 dark:bg-slate-950 p-4 md:p-6 rounded-xl flex justify-center">
            <div className="w-full max-w-[620px] bg-white text-slate-900 p-8 rounded-lg shadow-sm border border-slate-200 text-xs leading-relaxed space-y-3 font-sans">
              {file.wordHtml ? (
                <div
                  className="word-rendered-content prose prose-sm max-w-none text-slate-800"
                  dangerouslySetInnerHTML={{ __html: file.wordHtml }}
                />
              ) : (
                <div className="text-slate-500 italic">
                  {file.extractedText || 'No text extracted from Word document.'}
                </div>
              )}
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-700 flex items-center justify-between">
            <span className="text-xs text-slate-500 dark:text-slate-400">
              Target format: <strong className="text-slate-700 dark:text-slate-200">{pageSize.toUpperCase()} PDF</strong>
            </span>
            <button
              onClick={handleConvertAndDownload}
              className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 active:scale-95 text-white px-5 py-2.5 rounded-xl font-bold text-xs shadow-md shadow-indigo-600/20 transition-all"
            >
              <Download className="w-4 h-4" />
              <span>Convert & Download PDF</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
