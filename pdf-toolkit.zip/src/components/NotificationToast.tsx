import React from 'react';
import { CheckCircle2, AlertCircle, X } from 'lucide-react';

interface ToastProps {
  message: string | null;
  type?: 'success' | 'error' | 'info';
  onClose: () => void;
}

export const NotificationToast: React.FC<ToastProps> = ({
  message,
  type = 'success',
  onClose,
}) => {
  if (!message) return null;

  const isSuccess = type === 'success';
  const isError = type === 'error';

  return (
    <div className="fixed bottom-6 right-6 z-50 max-w-md animate-in fade-in slide-in-from-bottom-5 duration-200">
      <div
        className={`flex items-start gap-3 p-4 rounded-xl shadow-xl border ${
          isSuccess
            ? 'bg-white dark:bg-slate-800 border-emerald-500/50 text-slate-900 dark:text-white'
            : isError
            ? 'bg-white dark:bg-slate-800 border-red-500/50 text-slate-900 dark:text-white'
            : 'bg-white dark:bg-slate-800 border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white'
        }`}
      >
        <div className="shrink-0 mt-0.5">
          {isSuccess && <CheckCircle2 className="w-5 h-5 text-emerald-500" />}
          {isError && <AlertCircle className="w-5 h-5 text-red-500" />}
        </div>
        <div className="flex-1 text-xs leading-relaxed font-medium">
          {message}
        </div>
        <button
          onClick={onClose}
          className="shrink-0 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
        >
          <X className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
