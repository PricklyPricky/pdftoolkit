import React from 'react';
import { Trash2, ChevronLeft, ChevronRight, FileText, Image as ImageIcon } from 'lucide-react';
import { UploadedFile } from '../types';

interface FileCardProps {
  file: UploadedFile;
  index: number;
  totalFiles: number;
  onRemove: (index: number) => void;
  onMoveLeft?: (index: number) => void;
  onMoveRight?: (index: number) => void;
  showReorder?: boolean;
}

export const FileCard: React.FC<FileCardProps> = ({
  file,
  index,
  totalFiles,
  onRemove,
  onMoveLeft,
  onMoveRight,
  showReorder = false,
}) => {
  const thumb = file.thumbnails[0];

  return (
    <div className="relative group bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 p-2.5 shadow-sm hover:shadow-md transition-all flex flex-col">
      {/* Top order badge and remove button */}
      <div className="flex items-center justify-between mb-2">
        <span className="text-[10px] font-bold text-slate-500 dark:text-slate-400 bg-slate-100 dark:bg-slate-700 px-2 py-0.5 rounded-full">
          #{index + 1}
        </span>
        <button
          onClick={() => onRemove(index)}
          className="text-slate-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-950/40 p-1 rounded-md transition-colors"
          title="Remove file"
        >
          <Trash2 className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Thumbnail */}
      <div className="aspect-[3/4] bg-slate-100 dark:bg-slate-900 rounded-lg overflow-hidden flex items-center justify-center border border-slate-100 dark:border-slate-700/60 mb-2.5 relative">
        {thumb ? (
          <img
            src={thumb}
            alt={file.name}
            className="w-full h-full object-contain p-1"
          />
        ) : (
          <div className="flex flex-col items-center justify-center text-slate-400 p-2 text-center">
            <FileText className="w-8 h-8 mb-1 opacity-50" />
            <span className="text-[10px]">No Preview</span>
          </div>
        )}
      </div>

      {/* File Info */}
      <div className="mt-auto">
        <p className="text-xs font-semibold text-slate-900 dark:text-white truncate" title={file.name}>
          {file.name}
        </p>
        <div className="flex items-center justify-between text-[10px] text-slate-500 dark:text-slate-400 mt-0.5">
          <span>{file.pageCount > 0 ? `${file.pageCount} ${file.pageCount === 1 ? 'Page' : 'Pages'}` : 'Document'}</span>
          <span>{file.sizeFormatted}</span>
        </div>
      </div>

      {/* Reorder Buttons (Merge tool) */}
      {showReorder && totalFiles > 1 && (
        <div className="flex items-center justify-between gap-1 mt-2 pt-2 border-t border-slate-100 dark:border-slate-700/60">
          <button
            onClick={() => onMoveLeft && onMoveLeft(index)}
            disabled={index === 0}
            className="flex-1 flex items-center justify-center p-1 rounded text-slate-500 hover:text-slate-900 hover:bg-slate-100 dark:hover:bg-slate-700 disabled:opacity-30 disabled:pointer-events-none"
            title="Move left"
          >
            <ChevronLeft className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => onMoveRight && onMoveRight(index)}
            disabled={index === totalFiles - 1}
            className="flex-1 flex items-center justify-center p-1 rounded text-slate-500 hover:text-slate-900 hover:bg-slate-100 dark:hover:bg-slate-700 disabled:opacity-30 disabled:pointer-events-none"
            title="Move right"
          >
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>
      )}
    </div>
  );
};
