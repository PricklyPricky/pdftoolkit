import React from 'react';
import {
  FileText,
  FileType,
  Combine,
  Scissors,
  LayoutGrid,
  ImagePlus,
  FileImage,
  Stamp,
  ListOrdered,
  Lock,
  ArrowRight,
  ShieldCheck,
  Zap,
} from 'lucide-react';
import { ToolDef, ToolId } from '../types';

interface ToolCardsProps {
  tools: ToolDef[];
  onSelectTool: (id: ToolId) => void;
}

const ICON_MAP: Record<string, React.ElementType> = {
  FileText,
  FileType,
  Combine,
  Scissors,
  LayoutGrid,
  ImagePlus,
  FileImage,
  Stamp,
  ListOrdered,
  Lock,
};

export const ToolCards: React.FC<ToolCardsProps> = ({ tools, onSelectTool }) => {
  return (
    <div className="space-y-12">
      {/* Hero Intro */}
      <div className="text-center max-w-3xl mx-auto pt-2">
        <h1 className="text-3xl md:text-5xl font-extrabold tracking-tight text-slate-900 dark:text-white mb-4">
          Every tool you need to use PDFs,{' '}
          <span className="text-red-500 underline decoration-red-200 dark:decoration-red-950 underline-offset-4">
            at your fingertips.
          </span>
        </h1>
        <p className="text-base md:text-lg text-slate-600 dark:text-slate-400 max-w-2xl mx-auto">
          100% Free, Private, and Client-Side. Convert PDF to Word, Word to PDF, merge, split,
          reorder, watermark, and organize without uploading files to any external server.
        </p>

        {/* Feature Highlights Pills */}
        <div className="flex flex-wrap items-center justify-center gap-3 mt-6 text-xs text-slate-500 dark:text-slate-400">
          <div className="flex items-center gap-1.5 px-3 py-1 bg-slate-100 dark:bg-slate-800 rounded-full">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
            <span>Zero server uploads</span>
          </div>
          <div className="flex items-center gap-1.5 px-3 py-1 bg-slate-100 dark:bg-slate-800 rounded-full">
            <Zap className="w-3.5 h-3.5 text-amber-500" />
            <span>Instant processing</span>
          </div>
          <div className="flex items-center gap-1.5 px-3 py-1 bg-slate-100 dark:bg-slate-800 rounded-full">
            <span className="w-2 h-2 rounded-full bg-red-500"></span>
            <span>PDF to Word & Word to PDF included</span>
          </div>
        </div>
      </div>

      {/* Featured / New Tools Section */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <span>Document Conversion</span>
              <span className="text-[10px] bg-red-100 text-red-600 dark:bg-red-900/40 dark:text-red-400 px-2 py-0.5 rounded-full font-bold uppercase tracking-wider">
                Featured
              </span>
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Convert seamlessly between PDF, Word (.docx), and high-resolution images.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {tools
            .filter((t) => t.category === 'convert')
            .map((tool) => {
              const Icon = ICON_MAP[tool.iconName] || FileText;
              return (
                <div
                  key={tool.id}
                  onClick={() => onSelectTool(tool.id)}
                  className="relative group bg-white dark:bg-slate-800/80 p-5 rounded-2xl border border-slate-200 dark:border-slate-700/80 hover:border-red-500 dark:hover:border-red-500 hover:shadow-lg hover:-translate-y-0.5 transition-all duration-200 cursor-pointer flex flex-col justify-between"
                >
                  {tool.badge && (
                    <span className="absolute top-4 right-4 bg-red-500 text-white text-[10px] font-bold px-2 py-0.5 rounded-md tracking-wider">
                      {tool.badge}
                    </span>
                  )}
                  <div>
                    <div className="w-11 h-11 rounded-xl bg-red-50 dark:bg-red-950/40 text-red-500 flex items-center justify-center mb-4 group-hover:bg-red-500 group-hover:text-white transition-colors">
                      <Icon className="w-5 h-5" />
                    </div>
                    <h3 className="font-bold text-base text-slate-900 dark:text-white mb-1.5 flex items-center gap-1.5">
                      <span>{tool.name}</span>
                    </h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed mb-4">
                      {tool.desc}
                    </p>
                  </div>

                  <div className="pt-2 border-t border-slate-100 dark:border-slate-700/60 flex items-center justify-between text-xs font-semibold text-slate-700 dark:text-slate-300 group-hover:text-red-500 dark:group-hover:text-red-400">
                    <span>Open tool</span>
                    <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                  </div>
                </div>
              );
            })}
        </div>
      </div>

      {/* Organize & Manage Section */}
      <div>
        <div className="mb-4">
          <h2 className="text-lg font-bold text-slate-900 dark:text-white">
            Organize & Edit
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Merge, split, reorder, rotate, and customize page numbers or watermarks.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {tools
            .filter((t) => t.category === 'organize' || t.category === 'edit' || t.category === 'security')
            .map((tool) => {
              const Icon = ICON_MAP[tool.iconName] || FileText;
              return (
                <div
                  key={tool.id}
                  onClick={() => onSelectTool(tool.id)}
                  className="group bg-white dark:bg-slate-800/80 p-5 rounded-2xl border border-slate-200 dark:border-slate-700/80 hover:border-red-500 dark:hover:border-red-500 hover:shadow-md hover:-translate-y-0.5 transition-all duration-200 cursor-pointer flex flex-col justify-between"
                >
                  <div>
                    <div className="w-10 h-10 rounded-xl bg-slate-100 dark:bg-slate-700/60 text-slate-700 dark:text-slate-300 flex items-center justify-center mb-3 group-hover:bg-red-500 group-hover:text-white transition-colors">
                      <Icon className="w-5 h-5" />
                    </div>
                    <h3 className="font-bold text-sm text-slate-900 dark:text-white mb-1">
                      {tool.name}
                    </h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed mb-4">
                      {tool.desc}
                    </p>
                  </div>

                  <div className="pt-2 border-t border-slate-100 dark:border-slate-700/60 flex items-center justify-between text-xs font-semibold text-slate-600 dark:text-slate-400 group-hover:text-red-500 dark:group-hover:text-red-400">
                    <span>Open tool</span>
                    <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                  </div>
                </div>
              );
            })}
        </div>
      </div>

      {/* Privacy Guarantee Box */}
      <div className="p-6 bg-blue-50/80 dark:bg-blue-950/20 rounded-2xl border border-blue-100 dark:border-blue-900/40 flex flex-col sm:flex-row items-start sm:items-center gap-4">
        <div className="w-12 h-12 rounded-xl bg-blue-500/10 text-blue-600 dark:text-blue-400 flex items-center justify-center shrink-0">
          <ShieldCheck className="w-6 h-6" />
        </div>
        <div className="flex-1">
          <h4 className="font-bold text-sm text-blue-900 dark:text-blue-200">
            Client-Side Privacy Guarantee
          </h4>
          <p className="text-xs text-blue-700 dark:text-blue-300/90 mt-0.5 leading-relaxed">
            All files are read and processed directly in your web browser utilizing WebAssembly and client-side JavaScript. Your documents and sensitive data are never uploaded or stored on any remote server.
          </p>
        </div>
      </div>
    </div>
  );
};
