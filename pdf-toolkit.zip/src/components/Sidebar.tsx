import React from 'react';
import {
  FileText,
  FileType,
  Combine,
  Scissors,
  LayoutGrid,
  ImagePlus,
  FileImage,
  Stamp,
  ListOrdered,
  Lock,
  Home,
} from 'lucide-react';
import { ToolId } from '../types';
import { TOOLS } from '../data/tools';

interface SidebarProps {
  currentTool: ToolId;
  onSelectTool: (id: ToolId) => void;
}

const ICON_MAP: Record<string, React.ElementType> = {
  FileText,
  FileType,
  Combine,
  Scissors,
  LayoutGrid,
  ImagePlus,
  FileImage,
  Stamp,
  ListOrdered,
  Lock,
};

export const Sidebar: React.FC<SidebarProps> = ({ currentTool, onSelectTool }) => {
  return (
    <aside className="w-64 bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 flex flex-col shrink-0 overflow-y-auto hidden lg:flex">
      <div className="p-4 space-y-6">
        <div>
          <button
            onClick={() => onSelectTool('home')}
            className={`w-full flex items-center gap-3 px-3 py-2 text-sm font-medium rounded-lg transition-all ${
              currentTool === 'home'
                ? 'bg-red-50 text-red-600 dark:bg-red-950/40 dark:text-red-400 font-semibold'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-slate-100'
            }`}
          >
            <Home className="w-4 h-4 shrink-0" />
            <span className="truncate">All Tools Overview</span>
          </button>
        </div>

        <div>
          <p className="text-[11px] font-semibold text-slate-400 dark:text-slate-500 uppercase tracking-wider mb-2 px-3">
            Convert Documents
          </p>
          <div className="space-y-1">
            {TOOLS.filter((t) => t.category === 'convert').map((tool) => {
              const Icon = ICON_MAP[tool.iconName] || FileText;
              const isActive = currentTool === tool.id;
              return (
                <button
                  key={tool.id}
                  onClick={() => onSelectTool(tool.id)}
                  className={`w-full flex items-center justify-between px-3 py-2 text-xs font-medium rounded-lg transition-all ${
                    isActive
                      ? 'bg-red-500 text-white font-semibold shadow-sm'
                      : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                  }`}
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-white' : 'text-slate-500 dark:text-slate-400'}`} />
                    <span className="truncate">{tool.name}</span>
                  </div>
                  {tool.badge && (
                    <span
                      className={`text-[10px] px-1.5 py-0.2 rounded font-bold uppercase tracking-wider ${
                        isActive
                          ? 'bg-white/20 text-white'
                          : 'bg-red-100 text-red-600 dark:bg-red-900/40 dark:text-red-400'
                      }`}
                    >
                      {tool.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        <div>
          <p className="text-[11px] font-semibold text-slate-400 dark:text-slate-500 uppercase tracking-wider mb-2 px-3">
            Organize & Manage
          </p>
          <div className="space-y-1">
            {TOOLS.filter((t) => t.category === 'organize').map((tool) => {
              const Icon = ICON_MAP[tool.iconName] || FileText;
              const isActive = currentTool === tool.id;
              return (
                <button
                  key={tool.id}
                  onClick={() => onSelectTool(tool.id)}
                  className={`w-full flex items-center gap-2.5 px-3 py-2 text-xs font-medium rounded-lg transition-all ${
                    isActive
                      ? 'bg-red-500 text-white font-semibold shadow-sm'
                      : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                  }`}
                >
                  <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-white' : 'text-slate-500 dark:text-slate-400'}`} />
                  <span className="truncate">{tool.name}</span>
                </button>
              );
            })}
          </div>
        </div>

        <div>
          <p className="text-[11px] font-semibold text-slate-400 dark:text-slate-500 uppercase tracking-wider mb-2 px-3">
            Edit & Security
          </p>
          <div className="space-y-1">
            {TOOLS.filter((t) => t.category === 'edit' || t.category === 'security').map((tool) => {
              const Icon = ICON_MAP[tool.iconName] || FileText;
              const isActive = currentTool === tool.id;
              return (
                <button
                  key={tool.id}
                  onClick={() => onSelectTool(tool.id)}
                  className={`w-full flex items-center gap-2.5 px-3 py-2 text-xs font-medium rounded-lg transition-all ${
                    isActive
                      ? 'bg-red-500 text-white font-semibold shadow-sm'
                      : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                  }`}
                >
                  <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-white' : 'text-slate-500 dark:text-slate-400'}`} />
                  <span className="truncate">{tool.name}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </aside>
  );
};
