import React from 'react';
import { Loader2 } from 'lucide-react';

interface GlobalLoaderProps {
  isLoading: boolean;
  text?: string;
  subtext?: string;
}

export const GlobalLoader: React.FC<GlobalLoaderProps> = ({
  isLoading,
  text = 'Processing document...',
  subtext = 'Your browser is converting your file client-side. Please wait.',
}) => {
  if (!isLoading) return null;

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white dark:bg-slate-800 p-8 rounded-2xl flex flex-col items-center shadow-2xl border border-slate-100 dark:border-slate-700 max-w-sm w-full text-center">
        <div className="w-14 h-14 rounded-2xl bg-red-50 dark:bg-red-950/40 text-red-500 flex items-center justify-center mb-4">
          <Loader2 className="w-8 h-8 animate-spin" />
        </div>
        <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-1">
          {text}
        </h3>
        <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
          {subtext}
        </p>
      </div>
    </div>
  );
};
