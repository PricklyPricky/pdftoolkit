import React, { useState, useEffect } from 'react';
import { ArrowLeft, ShieldCheck, Sparkles } from 'lucide-react';
import { ToolId, UploadedFile } from './types';
import { TOOLS } from './data/tools';
import { processUploadedFile } from './utils/pdfHelpers';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { ToolCards } from './components/ToolCards';
import { Dropzone } from './components/Dropzone';
import { PdfToWordWorkspace } from './components/workspaces/PdfToWordWorkspace';
import { WordToPdfWorkspace } from './components/workspaces/WordToPdfWorkspace';
import { OrganizeWorkspace } from './components/workspaces/OrganizeWorkspace';
import { GeneralWorkspace } from './components/workspaces/GeneralWorkspace';
import { GlobalLoader } from './components/GlobalLoader';
import { NotificationToast } from './components/NotificationToast';

export default function App() {
  const [currentTool, setCurrentTool] = useState<ToolId>('home');
  const [files, setFiles] = useState<UploadedFile[]>([]);
  const [isDark, setIsDark] = useState<boolean>(false);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [loaderText, setLoaderText] = useState<string>('Processing...');
  const [toast, setToast] = useState<{ message: string | null; type: 'success' | 'error' | 'info' }>({
    message: null,
    type: 'success',
  });

  // Dark mode initialization
  useEffect(() => {
    const savedTheme = localStorage.getItem('pdftoolkit_theme');
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    const initialDark = savedTheme ? savedTheme === 'dark' : prefersDark;

    setIsDark(initialDark);
    if (initialDark) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, []);

  const toggleDarkMode = () => {
    setIsDark((prev) => {
      const next = !prev;
      if (next) {
        document.documentElement.classList.add('dark');
        localStorage.setItem('pdftoolkit_theme', 'dark');
      } else {
        document.documentElement.classList.remove('dark');
        localStorage.setItem('pdftoolkit_theme', 'light');
      }
      return next;
    });
  };

  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'success') => {
    setToast({ message, type });
    setTimeout(() => {
      setToast((curr) => (curr.message === message ? { message: null, type: 'success' } : curr));
    }, 4500);
  };

  const setLoading = (loading: boolean, text: string = 'Processing document...') => {
    setIsLoading(loading);
    setLoaderText(text);
  };

  // Switch tools and reset files
  const handleSelectTool = (id: ToolId) => {
    setCurrentTool(id);
    setFiles([]);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Process uploaded files
  const handleFilesSelected = async (fileList: FileList | File[]) => {
    const rawFiles = Array.from(fileList);
    if (rawFiles.length === 0) return;

    setLoading(true, 'Reading and preparing file previews...');
    try {
      const processed: UploadedFile[] = [];
      for (const f of rawFiles) {
        const item = await processUploadedFile(f);
        processed.push(item);
      }

      setFiles((prev) => {
        // For single-file tools, replace
        if (
          currentTool === 'pdf-to-word' ||
          currentTool === 'word-to-pdf' ||
          currentTool === 'split' ||
          currentTool === 'reorder' ||
          currentTool === 'watermark' ||
          currentTool === 'page-numbers' ||
          currentTool === 'protect'
        ) {
          return processed.slice(0, 1);
        }
        // For multi-file tools (merge, img-to-pdf), append
        return [...prev, ...processed];
      });

      showToast(`Loaded ${processed.length} ${processed.length === 1 ? 'file' : 'files'} successfully.`);
    } catch (err: any) {
      console.error(err);
      showToast(err.message || 'Failed to read selected files.', 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleRemoveFile = (index: number) => {
    setFiles((prev) => {
      const updated = [...prev];
      updated.splice(index, 1);
      return updated;
    });
  };

  const handleMoveLeft = (index: number) => {
    if (index === 0) return;
    setFiles((prev) => {
      const updated = [...prev];
      const item = updated.splice(index, 1)[0];
      updated.splice(index - 1, 0, item);
      return updated;
    });
  };

  const handleMoveRight = (index: number) => {
    setFiles((prev) => {
      if (index >= prev.length - 1) return prev;
      const updated = [...prev];
      const item = updated.splice(index, 1)[0];
      updated.splice(index + 1, 0, item);
      return updated;
    });
  };

  const activeToolDef = TOOLS.find((t) => t.id === currentTool);

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col font-sans transition-colors duration-200">
      {/* Top Header */}
      <Header
        currentTool={currentTool}
        onNavigate={handleSelectTool}
        isDark={isDark}
        onToggleTheme={toggleDarkMode}
      />

      {/* Main Layout Area */}
      <div className="flex flex-1 overflow-hidden">
        {/* Left Sidebar */}
        <Sidebar currentTool={currentTool} onSelectTool={handleSelectTool} />

        {/* Content Viewport */}
        <main className="flex-1 overflow-y-auto p-4 md:p-8">
          <div className="max-w-6xl mx-auto space-y-6">
            {currentTool === 'home' ? (
              <ToolCards tools={TOOLS} onSelectTool={handleSelectTool} />
            ) : (
              <div>
                {/* Back to Home + Tool Header */}
                <div className="mb-6">
                  <button
                    onClick={() => handleSelectTool('home')}
                    className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-500 hover:text-red-500 dark:text-slate-400 dark:hover:text-red-400 mb-3 transition-colors cursor-pointer"
                  >
                    <ArrowLeft className="w-3.5 h-3.5" />
                    <span>Back to All Tools</span>
                  </button>

                  <div className="flex items-center gap-3">
                    <h2 className="text-2xl md:text-3xl font-extrabold text-slate-900 dark:text-white">
                      {activeToolDef?.name}
                    </h2>
                    {activeToolDef?.badge && (
                      <span className="bg-red-500 text-white text-[10px] font-bold px-2 py-0.5 rounded-md uppercase tracking-wider">
                        {activeToolDef.badge}
                      </span>
                    )}
                  </div>
                  <p className="text-xs md:text-sm text-slate-500 dark:text-slate-400 mt-1 max-w-2xl">
                    {activeToolDef?.desc}
                  </p>
                </div>

                {/* Dropzone if no files loaded */}
                {files.length === 0 ? (
                  activeToolDef && (
                    <Dropzone
                      tool={activeToolDef}
                      onFilesSelected={handleFilesSelected}
                      multiple={currentTool === 'merge' || currentTool === 'img-to-pdf'}
                    />
                  )
                ) : (
                  /* Tool-specific Workspace */
                  <div>
                    {currentTool === 'pdf-to-word' ? (
                      <PdfToWordWorkspace
                        file={files[0]}
                        onReset={() => setFiles([])}
                        setLoading={setLoading}
                        showToast={showToast}
                      />
                    ) : currentTool === 'word-to-pdf' ? (
                      <WordToPdfWorkspace
                        file={files[0]}
                        onReset={() => setFiles([])}
                        setLoading={setLoading}
                        showToast={showToast}
                      />
                    ) : currentTool === 'reorder' ? (
                      <OrganizeWorkspace
                        file={files[0]}
                        onReset={() => setFiles([])}
                        setLoading={setLoading}
                        showToast={showToast}
                      />
                    ) : (
                      <GeneralWorkspace
                        toolId={currentTool}
                        files={files}
                        onRemoveFile={handleRemoveFile}
                        onMoveLeft={handleMoveLeft}
                        onMoveRight={handleMoveRight}
                        onAddMoreFiles={handleFilesSelected}
                        onReset={() => setFiles([])}
                        setLoading={setLoading}
                        showToast={showToast}
                      />
                    )}
                  </div>
                )}
              </div>
            )}
          </div>
        </main>
      </div>

      {/* Global Processing Loader */}
      <GlobalLoader isLoading={isLoading} text={loaderText} />

      {/* Notification Toast */}
      <NotificationToast
        message={toast.message}
        type={toast.type}
        onClose={() => setToast({ message: null, type: 'success' })}
      />
    </div>
  );
}
